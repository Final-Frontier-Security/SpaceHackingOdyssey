#!/bin/bash
# Exit immediately if a command exits with a non-zero status
set -e


# Setup Flask server
echo "Setting up Flask server..."
cd /home/Operator/Desktop/garak/backend/app

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install Flask dependencies
pip install -r ../requirements.txt

# Run Flask server
echo "Starting Flask server..."
FLASK_APP=run.py flask run -p 5001 &

# Setup Vue frontend
echo "Setting up Vue frontend..."
cd ../../frontend

# Install Vue dependencies
npm install

# Run Vue development server
echo "Starting Vue development server..."
npm run serve &

echo "Both Flask and Vue servers are running."

# Wait for Flask and Vue servers to exit
wait
