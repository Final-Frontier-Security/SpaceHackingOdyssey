import threading
import socket
from scapy.all import *

class CloakingDevice:
    def __init__(self, telemetry_port=5013, forward_ip="10.10.20.10", packet_limit=1):
        self.telemetry_port = telemetry_port
        self.forward_ip = forward_ip
        self.packet_limit = packet_limit
        self._stop_event = threading.Event()
        self.received_packets = []
        self.status = "Deactivated"

    def activate(self, app):
        self.listener_thread = threading.Thread(target=self._activate, args=(app,))
        self.listener_thread.daemon = True
        self.listener_thread.start()
        self.status = "Activated"

    def _activate(self, app):
        with app.app_context():
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.bind(('0.0.0.0', self.telemetry_port))
            sock.settimeout(1.0)
            print(f"Listening for packets on 0.0.0.0:{self.telemetry_port}...")
            self.status = "packet_collection"
            while not self._stop_event.is_set() and len(self.received_packets) < self.packet_limit:
                try:
                    data, addr = sock.recvfrom(1024)
                    self.store_packet(data, addr)
                except socket.timeout:
                    continue

            if len(self.received_packets) >= self.packet_limit:
                self.status = "sending_packets"
                print("Received 100 packets, starting to forward in a loop...")
                self.forward_packets_loop()

    def store_packet(self, data, addr):
        self.received_packets.append((data, addr))
        print(f"Packet received from {addr[0]}:{addr[1]} - Total packets: {len(self.received_packets)}")

    def forward_packets_loop(self):
        while not self._stop_event.is_set():
            for data, addr in self.received_packets:
                src_ip = addr[0]
                src_port = addr[1]
                dst_ip = self.forward_ip
                dst_port = self.telemetry_port

                ip_header = IP(src='10.10.20.20', dst=dst_ip)
                udp_header = UDP(sport=src_port, dport=dst_port)
                packet = ip_header / udp_header / data
                send(packet, verbose=0)
                print(f"Forwarded packet from {src_ip} to {dst_ip}")

    def deactivate(self):
        self._stop_event.set()
        self.listener_thread.join()
        self.status = "Deactivated"
        print("Cloaking device deactivated.")
