from flask import Flask, request, jsonify, render_template, redirect, url_for
from flask_migrate import Migrate
from models import db, Target, Command, CommandParameter, InterceptedCommand, InterceptedCommandParameter, Setting
from services import command_parser, command_sender, command_interceptor, cloaking_device
from sqlalchemy.orm import aliased, joinedload
from flask_cors import CORS
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///stargate.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# enable CORS
CORS(app, resources={r'/*': {'origins': '*'}})

db.init_app(app)
migrate = Migrate(app, db)
satellite_ip = '10.10.10.10'
groundstation_ip = '10.10.20.10'
command_port = 5012
telemetry_port = 5013
interceptor = command_interceptor.Interceptor(command_port)
cloak = cloaking_device.CloakingDevice(telemetry_port=telemetry_port, forward_ip=groundstation_ip)

@app.route("/api/target", methods=['GET'])
def get_targets():
    targets = Target.query.all()
    return jsonify([target.to_dict() for target in targets])

@app.route("/api/target/<int:target_id>", methods=['GET'])
def get_target(target_id):
    target = Target.query.get_or_404(target_id)
    return jsonify(target)

@app.route("/api/target/<int:target_id>/command/<int:command_id>", methods=['GET'])
def get_target_command(target_id, command_id):
    target = Target.query.options(joinedload(Target.commands)).filter_by(id=target_id).first_or_404()
    command = Command.query.options(joinedload(Command.parameters)).filter_by(target_id=target.id, id=command_id).first_or_404()

    return jsonify({'target': target, 'command': command})

@app.route("/api/target/<int:target_id>/command/<int:command_id>/execute", methods=["POST"])
def execute_command(target_id, command_id):
    target = Target.query.filter_by(id=target_id).first()
    command = Command.query.filter_by(id=command_id).first()
    parameters = command.parameters
    request_data = request.get_json()
    for request_parameter in request_data:
        for parameter in parameters:
            if parameter.name == request_parameter["name"] and "CCSDS" not in parameter.name:
                parameter.default = request_parameter["default"]
    command_packet = command_sender.create_command_packet(target, command, parameters)
    command_sender.send_command_packet(satellite_ip, 5012, command_packet)

    return jsonify("Sent Successfully")

@app.route("/api/interceptor/start", methods=["POST"])
def start_interceptor():
    interceptor.start(app)

    return jsonify("Interceptor started")

@app.route("/api/interceptor/stop", methods=["POST"])
def stop_interceptor():
    interceptor.stop()

    return jsonify("Interceptor stopped")

@app.route("/api/interceptor/status", methods=["GET"])
def get_interceptor_status():
    return jsonify({"status": interceptor.status})

@app.route("/api/interceptor/command", methods=["GET"])
def intercepted_commands():
    intercepted_commands = InterceptedCommand.query.all()
    
    return jsonify([intercepted_command.to_dict() for intercepted_command in intercepted_commands])

@app.route("/api/interceptor/command/<int:intercepted_command_id>", methods=["GET"])
def intercepted_command(intercepted_command_id):
    intercepted_command = InterceptedCommand.query.get_or_404(intercepted_command_id)
    command = intercepted_command.command
    target = command.target

    # Alias the models for clearer references
    icp = aliased(InterceptedCommandParameter)
    cp = aliased(CommandParameter)

    # Perform the join and select the desired columns
    query = db.session.query(icp, cp).join(cp, icp.base_parameter_id == cp.id)

    # Execute the query and fetch the results
    results = query.all()

    print(results)

    return jsonify({
        "target": target.as_dict(),
        "command": command.as_dict(),
        "parameters": [result[0].as_dict() for result in results]
    })

@app.route("/api/interceptor/clear", methods=["POST"])
def clear_intercepted_commands():
    InterceptedCommand.query.delete()
    InterceptedCommandParameter.query.delete()

    db.session.commit()

    return jsonify({"message": "All intercepted commands cleared"})

@app.route("/api/cloak", methods=["GET"])
def cloaking():
    return jsonify({"status": cloak.status, "packet_count": len(cloak.received_packets)})

@app.route("/api/cloak/activate",methods=["POST"])
def enable_cloak():
    cloak.activate(app)

    return jsonify({"active": True, "status": cloak.status})

@app.route("/api/cloak/deactivate",methods=["POST"])
def disable_cloak():
    cloak.deactivate()
    return jsonify({"active": False, "status": cloak.status})
 
@app.route("/api/readyroom", methods=["GET"])
def readyroom():
    return jsonify([setting.to_dict() for setting in Setting.query.all()])

@app.route("/api/readyroom", methods=["POST"])
def update_readyroom():
    settings = Setting.query.all()
    for setting in settings:
        if setting.name in request.form:
            setting.value = request.form[setting.name]
    db.session.commit()

    return jsonify("Settings updated")

#create targets, commands, and command_parameters from zip of COSMO
#command configuration files
@app.route('/api/readyroom/cosmos/upload', methods=['POST'])
def upload_file():
    #Prevent duplicates
    Target.query.delete()
    Command.query.delete()
    CommandParameter.query.delete()
    setting = Setting.query.filter(Setting.name == 'configs_loaded').first()
    setting.value = 'False'

    db.session.commit()
    # Check if the post request has the file part
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400

    file = request.files['file']

    # If the user does not select a file, the browser also
    # submits an empty part without filename
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file and file.filename.endswith('.zip'):
        configs = command_parser.extract_config_files(file)
        for target_name in configs:
            target = Target.create_from_config(target_name)
            for command_name in configs[target_name]:
                command = Command.create_from_config(target.id, command_name, configs[target_name][command_name])
                for command_parameter_config in configs[target_name][command_name]["parameters"]:
                    command_parameter = CommandParameter.create_from_config(command.id, command_parameter_config)
        targets = Target.query.all()
        commands = Command.query.all()
        command_parameters = CommandParameter.query.all()
        return jsonify({'success': 'File uploaded', 'targets': len(targets), 'commands': len(commands), 'command_parameters': len(command_parameters)})
    else:
        return jsonify({'error': 'Invalid file type'}), 400
    
@app.route('/api/readyroom/cosmos', methods=['DELETE'])
def delete_cosmos_configs():
    Target.query.delete()
    Command.query.delete()
    CommandParameter.query.delete()
    setting = Setting.query.filter(Setting.name == 'configs_loaded').first()
    setting.value = 'False'

    db.session.commit()

    return jsonify("COSMO configurations deleted")

@app.route('/api/controlpanel/command', methods=['POST'])
def execute_shell_command():
    request_data = request.get_json()
    command = request_data['command']
    os.system(command)

    return jsonify("Command executed")

@app.route('/api/readyroom/command/count', methods=['GET'])
def command_count():
    return jsonify(Command.query.count())

if __name__ == '__main__':
    app.run(debug=True) # Run the app in debug mode


# export FLASK_APP=run.py
# flask db init    # Run this only once
# flask db migrate -m "Initial migration."  # Run this to create initial migrations
# flask db upgrade  # Run this to apply migrations
# python setup-db.py  # Run this to prepopulate the database with initial settings

# From windows command prompt:
# set FLASK_APP=run.py
# python -m venv env
# env\Scripts\activate
# pip install -r requirements.txt
# flask db init
