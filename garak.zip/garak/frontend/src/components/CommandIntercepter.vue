<template>
  <div>
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Command Interceptor</h5>
        <div class="form-check form-switch">
          <input
            class="form-check-input"
            type="checkbox"
            id="flexSwitchCheckChecked"
            :checked="interceptorActivated"
            @change="toggleInterceptor"
          />
          <label class="form-check-label" for="flexSwitchCheckChecked">Activate</label>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Intercepted Commands</h5>
        <div class="form-check form-switch">
          <div class="card-body">
            <form @submit.prevent="handleSubmit">

              <!-- Step 1: Command -->
              <div v-if="currentStep === 1">
                <ul class="list-group">
                  <li
                    v-for="command in interceptedCommands"
                    :key="command.id"
                    class="list-group-item list-group-item-action"
                    @click="selectCommand(command)"
                  >
                    {{ command['command'].target.name + ' - ' + command['command'].name }}
                    </li>
                    </ul>
              </div>

              <!-- Step 2: Command Parameters -->
              <div v-if="currentStep === 2">
                <form @submit.prevent="submitCommand">
                  <div v-if="interceptedCommandParameters.length === 0">
                    <p>No parameters available for this command</p>
                  </div>
                  <div v-for="param in interceptedCommandParameters" :key="param.name" class="mb-3">
                    <label :for="param.name" class="form-label">{{ param.description }}</label>
                    <input :disabled="param.description.startsWith('CCSDS')"
                      type="text"
                      class="form-control"
                      :id="param.name"
                      v-model="param.default"
                    />
                    <!-- Add other input types as needed -->
                  </div>
                  <button type="submit" class="btn btn-primary">Send Command</button>
                  </form>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Clear Intercepted Packets</h5>
        <button @click="clearInterceptedCommands()" class="btn btn-danger">Clear</button>
      </div>
    </div>
  </div>
</template>

<script>
import api from '@/services/api'

export default {
  name: 'CommandIntercepter',
  data() {
    return {
      interceptorActivated: false,
      interceptedTargets: [],
      interceptedCommands: [],
      interceptedCommandParameters: [],
      selectedTarget: null,
      selectedCommand: null,
      parameters: [],
      packetCount: 0,
      intervalId: null,
      currentStep: 1
    };
  },
  created() {
    this.setup();
  },
  beforeUnmount() {
    this.clearInterval();
  },
  methods: {
    async setup() {
      try {
        const response = await api.getInterceptorStatus();
        this.interceptorActivated = !(response.data.status === "Deactivated");
        if (this.interceptorActivated) {
          this.startInterval();
        }
      } catch (error) {
        console.error(error);
      }
    },
    async clearInterceptedCommands() {
      const response = await api.clearInterceptedCommands();
      alert(response.data.message);
    },
    async toggleInterceptor() {
      try {
        if (this.interceptorActivated) {
          const response = await api.stopInterceptor();
          this.clearInterval();
          this.cloakStatus = response.data.status;
        } else {
          const response = await api.startInterceptor();
          this.startInterval();
          this.cloakStatus = response.data.status;
        }
        this.interceptorActivated = !this.interceptorActivated;
      } catch (error) {
        alert(error);
      }
    },
    startInterval() {
      this.intervalId = setInterval(async () => {
        try {
          const response = await api.getInterceptedCommands();
          this.interceptedCommands = response.data;
          console.log(response.data);
        } catch (error) {
          console.error(error);
        }
      }, 5000);
    },
    clearInterval() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
    },
    selectCommand(command) {
      this.selectedCommand = command;
      let joinedParams = [];
      for (let parameter of command.command.parameters) {
        for (let interceptedParameter of command.parameters) {
          if (parameter.id === interceptedParameter.base_parameter_id) { 
            if (!parameter.name.includes("CCSDS")) { 
              parameter.default = interceptedParameter.value;
              console.log(parameter);
            }
          }
        }
        console.log(parameter);
        joinedParams.push(parameter); // Correct the indentation
  }
  this.interceptedCommandParameters = joinedParams;
  this.selectedTarget = command.command.target;
  this.currentStep = 2;
},
    async submitCommand() {
      try {
        await api.executeCommand(this.selectedTarget.id, this.selectedCommand.command.id, this.interceptedCommandParameters);
        alert('Command sent successfully');
        this.currentStep = 1;
      } catch (error) {
        console.error('Error sending command:', error);
        alert('Failed to send command');
        this.currentStep = 1;
      }
    }
  }
};
</script>
