<template>
    <h1>Ready Room</h1>
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Settings</h5>
        <form>
            <div class="mb-3" v-for="setting in settings" :key="setting.id">
            <label :for="`setting-${setting.id}`" class="form-label">{{ convertString(setting.name) }}</label>
            <input
                type="text"
                class="form-control"
                :id="`setting-${setting.id}`"
                :value="setting.value"
            />
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Commands</h5>
            <p class="card-text">Number of commands: {{ commandCount }}</p>
            <form @submit.prevent="uploadFile" enctype="multipart/form-data">
                <input type="file" @change="handleFileChange" />
                <button type="submit" class="btn btn-primary" value="Upload">Upload</button>
            </form>
            <br />
            <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#clearCommandsModal">
                Clear Commands
            </button>
        </div>
      </div>

      <div class="modal fade" id="clearCommandsModal" tabindex="-1" aria-labelledby="clearCommandsModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="resetCommandsModalLabel">Clear COSMOS Commands</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Select Clear to remove all COSMOS commands.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" @click="clearCommands" class="btn btn-danger" data-bs-dismiss="modal">CLEAR</button>
            </div>
            </div>
        </div>
    </div>
</template>
  
  <script>
  import api from '@/services/api'
  
  export default {
    name: 'ReadyRoom',
    data() {
        return {
        settings: [],
        commandCount: 0
        };
    },
    created() {
        this.setup();
    },
    methods: {
        async setup() {
            try {
                this.updateCommandCount();
                const readyRoomResponse = await api.getReadyRoom();
                this.settings = readyRoomResponse.data;
            } catch (error) {
                console.error(error);
            }
        },
        async updateCommandCount() {
                const commandsResponse = await api.getCommandCount();
                this.commandCount = commandsResponse.data;
        },
        convertString(value) {
            value = value
            .split('_')
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(' ');
            if (value.slice(-2) === 'Ip') {
                value = value.slice(0, -2) + 'IP';
            }
            return value;
        },
        async clearCommands() {
            try {
                const response = await api.deleteCOSMOSConfigs();
                alert(response.data)
            } catch (error) {
                console.error(error);
            }
        },
        handleFileChange(event) {
            this.file = event.target.files[0];
        },
        async uploadFile() {
            if (!this.file) {
                alert('Please select a file to upload');
                return;
            }

            const configZip = new FormData();
            configZip.append('file', this.file);

            try {
                const response = await api.uploadCOSMOSConfigZip(configZip);
                if (response.status === 200) {
                    alert('File uploaded successfully');
                } else {
                    alert('Failed to upload file');
                }
            } catch (error) {
                console.error('Error uploading file:', error);
                alert('An error occurred while uploading the file');
            }
        }
    }
    };
  </script> 
  