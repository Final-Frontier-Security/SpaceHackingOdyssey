<template>
  <div class="container">
    <h1>Control Panel</h1>
    <button disabled class="btn btn-primary m-2" @click="deployBackdoor">Deploy Backdoor</button>
    <button disabled class="btn btn-secondary m-2" @click="downlink">Downlink</button>
    <button class="btn btn-danger m-2" @click="kill42">Kill 42</button>
    <button class="btn btn-success m-2" @click="start42">Start 42</button>
  </div>
</template>

<script>
import api from '@/services/api'

export default {
  name: 'ControlPanel',
  methods: {
    deployBackdoor() {
      this.executeCommand("scp -o StrictHostKeyChecking=no -i /home/Operator/.ssh/groundstation.pem /home/Operator/Desktop/backdoor/backdoor.so ubuntu@moonlighter.spacevehicle.space:/opt/nos3/fsw/build/exe/cpu1/cf/backdoor.so");
    },
    downlink() {
      this.executeCommand("scp -o StrictHostKeyChecking=no -i /home/Operator/.ssh/groundstation.pem ubuntu@moonlighter.spacevehicle.space:/opt/nos3/fsw/build/exe/cpu1/data/*.txt /home/Operator/Desktop/havoc/downlink/");
    },
    kill42() {
      this.executeCommand("docker stop $(docker ps -a -q)");
    },
    start42() {
      this.executeCommand("/home/Operator/Desktop/42-start.sh");
    },
    async executeCommand(command) {
      try {
        await api.executeShellCommand(command);
        alert('Command sent successfully');
      } catch (error) {
        console.error('Error sending command:', error);
        alert('Failed to send command');
      }
    }
  }
}
</script>

<style scoped>
.container {
  margin-top: 50px;
}
</style>
