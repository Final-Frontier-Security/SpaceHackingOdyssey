<template>
  <div>
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Cloaking Device</h5>
        <div class="form-check form-switch">
          <input
            class="form-check-input"
            type="checkbox"
            id="flexSwitchCheckChecked"
            :checked="cloakActivated"
            @change="toggleCloak"
          />
          <label class="form-check-label" for="flexSwitchCheckChecked">Activate</label>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Cloak Status - <small v-bind:class="statusMessages[cloakStatus]['color']">{{ statusMessages[cloakStatus]['message'] }}</small></h5>
        <div v-if="cloakActivated && cloakStatus == 'packet_collection'">
          <p class="card-text">{{ packetCount }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from '@/services/api'

export default {
  name: 'CloakingDevice',
  data() {
    return {
      cloakActivated: false,
      cloakStatus: "Deactivated",
      packetCount: 0,
      intervalId: null,
      statusMessages: {
        "Deactivated": {"message":"Deactivated", "color":"text-danger"},
        "Activated": {"message":"Activated", "color":"text-success"},
        "packet_collection": {"message":"Collecting 100 packets...", "color":"text-success"},
        "sending_packets": {"message":"Sending Looped Telemetry to Groundstation...", "color":"text-primary"}
      }
    };
  },
  created() {
    this.setup();
  },
  beforeUnmount() {
    this.clearInterval();
  },
  methods: {
    async setup() {
      try {
        const response = await api.getCloakStatus();
        this.cloakActivated = !(response.data.status === "Deactivated");
        this.packetCount = response.data.packet_count;
        if (this.cloakActivated) {
          this.startInterval();
        }
      } catch (error) {
        console.error(error);
      }
    },
    async toggleCloak() {
      try {
        if (this.cloakActivated) {
          const response = await api.deactivateCloak();
          this.clearInterval();
          this.cloakStatus = response.data.status;
        } else {
          const response = await api.activateCloak();
          this.startInterval();
          this.cloakStatus = response.data.status;
        }
        this.cloakActivated = !this.cloakActivated;
      } catch (error) {
        alert(error);
      }
    },
    startInterval() {
      this.intervalId = setInterval(async () => {
        try {
          const response = await api.getCloakStatus();
          this.cloakStatus = response.data.status;
          this.packetCount = response.data.packet_count;
        } catch (error) {
          console.error(error);
        }
      }, 2000);
    },
    clearInterval() {
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
    }
  }
};
</script>
