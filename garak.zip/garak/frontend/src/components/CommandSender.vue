<template>
    <div class="card">
      <div class="card-header">
        <h3>{{ headings[parseInt(currentStep) - 1]}}</h3>
      </div>
      <div class="card-body">
        <form @submit.prevent="handleSubmit">
          <!-- Step 1: Target -->
          <div v-if="currentStep === 1">
            <ul class="list-group">
              <li
                v-for="target in targets"
                :key="target.id"
                class="list-group-item list-group-item-action"
                @click="selectTarget(target)"
              >
                {{ target.name }}
              </li>
            </ul>
          </div>

          <!-- Step 2: Command -->
          <div v-if="currentStep === 2">
            <ul class="list-group">
              <li
                v-for="command in commands"
                :key="command.id"
                class="list-group-item list-group-item-action"
                @click="selectCommand(command)"
              >
                {{ command.name }}
                </li>
                </ul>
          </div>

          <!-- Step 3: Command Parameters -->
          <div v-if="currentStep === 3">
            <form @submit.prevent="submitCommand">
              <div v-if="parameters.length === 0">
                <p>No parameters available for this command</p>
              </div>
              <div v-for="param in parameters" :key="param.name" class="mb-3">
                <label :for="param.name" class="form-label">{{ param.description }}</label>
                <input :disabled="param.description.startsWith('CCSDS')"
                  type="text"
                  class="form-control"
                  :id="param.name"
                  v-model="param.default"
                />
                <!-- Add other input types as needed -->
              </div>
              <button type="submit" class="btn btn-primary">Send Command</button>
              </form>
          </div>
        </form>
      </div>
    </div>
</template>

<script>
import api from '@/services/api'

export default {
  name: 'CommandSender',
  data() {
    return {
      currentStep: 1,
      headings: ['Select Target', 'Select Command', 'Select Command Parameters'],
      targets: [],
      commands: [],
      parameters: [],
      selectedTarget: null,
      selectedCommand: null
    };
  },
  async created() {
    await this.fetchTargets();
  },
  methods: {
    async fetchTargets() {
      try {
        const response = await api.getTargets();
        this.targets = response.data;
      } catch (error) {
        console.error('Error fetching targets:', error);
      }
    },
    selectTarget(target) {
      this.selectedTarget = target;
      this.commands = this.selectedTarget.commands;
      this.nextStep();
    },
    selectCommand(command) {
      this.selectedCommand = command;
      console.log(command)
      console.log(command.parameters)
      this.parameters = command.parameters;
      this.nextStep();
    },
    nextStep() {
      if (this.currentStep < 3) {
        this.currentStep++;
      }
    },
    prevStep() {
      if (this.currentStep > 1) {
        this.currentStep--;
      }
    },
    async submitCommand() {
      try {
        await api.executeCommand(this.selectedTarget.id, this.selectedCommand.id, this.parameters);
        alert('Command sent successfully');
      } catch (error) {
        console.error('Error sending command:', error);
        alert('Failed to send command');
      }
    }
  }
};
</script>

<style scoped>
.step {
  display: none;
}
.step.active {
  display: block;
}
</style>
