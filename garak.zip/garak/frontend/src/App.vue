<template>
  <div id="app">
    <GarakHome />
  </div>
</template>

<script>
import GarakHome from '@/views/GarakHome.vue';

export default {
  name: 'App',
  components: {
    GarakHome,
  },
};
</script>

<style>
/* Add global styles here */
</style>
